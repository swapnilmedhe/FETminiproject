var name, uname, email, mobile, password, retype_password, cp_pass,cp_cpass,cp_uname;


var error_name=false;
var error_uname=false;
var error_email=false;
var error_mobile=false;
var error_password=false;
var error_message=false;
var error_retype_password=false;

 
$(function(){
  //  debugger;
    $("#name_error_msg").hide();
    $("#uname_error_msg").hide();
    $("#email_error_msg").hide();
    $("#mobile_error_msg").hide();
    $("#message_error_msg").hide();
    $("#password_error_msg").hide();
    $("#retype_password_error_msg").hide();

    $("#form_name").focusout(function(){
        check_name();
    });

    $("#form_uname").focusout(function(){
        check_uname();
    });

    $("#form_email").focusout(function(){
        check_email();
    });

    $("#form_mobile").focusout(function(){
        check_mobile();
    });

    $("#form_message").focusout(function(){
        check_message();
    });

    $("#form_password").focusout(function(){
        check_password();
    });

    $("#form_retype_password").focusout(function(){
        check_retype_password();
    });

    checkCookie();

    //function to log out
    document.getElementById("logout_anchor").onclick= function(){
       deleteUser();
    }


});


//function to validate name
function check_name(){
    var pattern =/^[a-zA-Z ]+$/;
    name= $("#form_name").val();
    if(pattern.test(name) && name !== ""){
        $("#name_error_msg").hide();
        $("#form_name").removeClass("errorColor");
        $("#form_name").addClass("normalColor");
    }
    else{
        $("#name_error_msg").html("Should contain only characters");
        $("#name_error_msg").show();
        $("#form_name").removeClass("normalColor");
        $("#form_name").addClass("errorColor");
        error_name=true;
    }
}


//function to validate user name
function check_uname(){
    var pattern =/^[a-zA-Z]+$/;
    uname= $("#form_uname").val();
    if(pattern.test(uname) && uname !== ""){
        $("#uname_error_msg").hide();
        $("#form_uname").removeClass("errorColor");
        $("#form_uname").addClass("normalColor");
    }
    else{
        $("#uname_error_msg").html("Should contain only characters");
        $("#uname_error_msg").show();
        $("#form_uname").removeClass("normalColor");
        $("#form_uname").addClass("errorColor");
        error_uname=true;
    }
}


//function to validate email
function check_email(){
    var pattern =/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    email= $("#form_email").val();
    if(pattern.test(email) && email !== ""){
        $("#email_error_msg").hide();
        $("#form_email").removeClass("errorColor");
        $("#form_email").addClass("normalColor");
    }
    else{
        $("#email_error_msg").html("Invalid Email");
        $("#email_error_msg").show();
        $("#form_email").removeClass("normalColor");
        $("#form_email").addClass("errorColor");
        error_email=true;
    }
}

//function to validate mobile
function check_mobile(){
    var pattern =/^[0][1-9]\d{9}$|^[1-9]\d{9}$/;
    mobile= $("#form_mobile").val();
    if(pattern.test(mobile) && mobile !== ""){
        $("#mobile_error_msg").hide();
        $("#form_mobile").removeClass("errorColor");
        $("#form_mobile").addClass("normalColor");
    }
    else{
        $("#mobile_error_msg").html("Enter 10 digit number");
        $("#mobile_error_msg").show();
        $("#form_mobile").removeClass("normalColor");
        $("#form_mobile").addClass("errorColor");
        error_mobile=true;
    }
}

//function to validate message box
function check_message(){
    if( $("#form_message").val() !== ""){
        $("#message_error_msg").hide();
        $("#form_message").removeClass("errorColor");
        $("#form_message").addClass("normalColor");
    }
    else{
        $("#message_error_msg").html("Enter message");
        $("#message_error_msg").show();
        $("#form_message").removeClass("normalColor");
        $("#form_message").addClass("errorColor");
        error_message=true;
    }
}

//function to validate password
function check_password(){
    password =$("#form_password").val();
    var password_length = $("#form_password").val().length;
    if(password_length<6 ){
        $("#password_error_msg").html("Atleast 6 characters");
        $("#password_error_msg").show();
        $("#form_password").removeClass("normalColor");
        $("#form_password").addClass("errorColor");
        error_password=true;
    }
    else{
        $("#password_error_msg").hide();
        $("#form_password").removeClass("errorColor");
        $("#form_password").addClass("normalColor");
    }
}

//function to validate retype password
function check_retype_password(){
    password = $("#form_password").val();
    retype_password = $("#form_retype_password").val();
    if(password !== retype_password){
        $("#retype_password_error_msg").html("Passwords did not matched");
        $("#retype_password_error_msg").show();
        $("#form_retype_password").removeClass("normalColor");
        $("#form_retype_password").addClass("errorColor");
        error_retype_password=true;
    }
    else{
        $("#retype_password_error_msg").hide();
        $("#form_retype_password").removeClass("errorColor");
        $("#form_retype_password").addClass("normalColor");
    }
}


//function to check username
function checkCookie() {
    var user=JSON.parse(localStorage.getItem("username"));
    if (localStorage.getItem("username") != null) {
        document.getElementById("login_div").style.display="none";
        document.getElementById("userName").innerHTML=user;
        document.getElementById("logout_div").style.display="block";
        document.getElementById("disable_form").disabled=true;
        return true;
    } 
    else 
    {
        document.getElementById("login_div").style.display="block";
        document.getElementById("logout_div").style.display="none";
        document.getElementById("disable_form").disabled=false;
        return false;
    }
}

//function to delete logout user
function deleteUser() {
    alert("You are successfully logged out");
    localStorage.removeItem("username");
}

//function to call on login click
function userLogin(){
   // debugger;
    error_uname=false;
    error_password=false;
    check_uname();
    check_password();
    if( !checkCookie()){

        if(error_uname ===false && error_password === false){

            var arr =JSON.parse(localStorage.getItem("users_array"));
            for(var i=0;i<arr.length;i++)
            {
                if(uname == arr[i].UserName  && password ==arr[i].Password )
                {
                localStorage.setItem("username", JSON.stringify(arr[i].Name).toUpperCase());
                alert("Succesfully Logged in");
                return true;
                }       
            }//for ends
            alert("username or password invalid!!!");
            return false;
            }//outer if ends
            else{
                alert("username or password invalid!!!");
                return false;
            }
    }
    else{
        alert("User already logged in!!!");
    }
};


//function to call on register click
function userRegister(){
   // debugger;
     error_name=false;
     error_uname=false;
     error_email=false;
     error_mobile=false;
     error_password=false;
     error_retype_password=false;

     check_name();
     check_uname();
     check_email();
     check_mobile();
     check_password();
     check_retype_password();
     if( !checkCookie()){
     if(error_name ===false && error_uname === false && error_email=== false && error_mobile ===false && error_password === false && error_retype_password === false)
     {
        var userObj={Name:name, UserName:uname, Email:email, Mobile:mobile, Password:password};
        //Storing data:
        var userArray = [];
            if (localStorage.getItem("users_array") === null) {
                userArray.push(userObj);
                //Storing data:
                localStorage.setItem("users_array", JSON.stringify(userArray));
                alert("Registration Successfull");
                return true;
            }
            else{
                //Retrieving data:
                userArray =JSON.parse(localStorage.getItem("users_array"));
                for(var i=0;i<userArray.length;i++)
                    {
                            if(userArray[i].UserName.toUpperCase() != uname.toUpperCase()  && userArray[i].Email.toUpperCase() != email.toUpperCase() )
                            {
                                userArray.push(userObj);
                                //Storing data:
                                localStorage.setItem("users_array", JSON.stringify(userArray));
                                alert("Registration Successfull");
                                return true;
                               
                            }
                            else
                            {
                                alert("User already exists");
                                return false;
                            }
                        }
                
            }//else ends here        
        }//
     else{
         alert("Please fill the form Correctly");
         return false;
     }
    }
    else{
        alert("User already logged in!!!  You need to logout first!");
    }
};

//function to change password
function changePassword(){
     debugger;
    error_uname=false;
    error_password=false;
    error_retype_password=false;

    check_uname();
    check_password();
    check_retype_password();
        if(error_uname === false && error_password === false && error_retype_password === false){
            userArray=JSON.parse(localStorage.getItem("users_array"));
            for(var j=0;j<userArray.length;j++)
            {
                if(uname == userArray[j].UserName )
                {
                    userArray[j].Password=password;
                    localStorage.setItem("users_array", JSON.stringify(userArray));
                    alert("Password Changed Successfully");
                    return true;
                }     
            }
            alert("Enter correct username!!!");
        }
        else{
            alert("Password updation Failed");
            return false;
        }
    

};